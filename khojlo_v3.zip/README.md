# Khojlo

AI-assisted local directory for tutors, services and jobs in Delhi.

- index.html: live site (Supabase)
- schema.sql then schema_v2.sql: Supabase schema, RLS, lead matching
